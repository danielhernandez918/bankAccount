public class BankAccountTest {
    
    public static void main(String[] args) {
        BankAccount user1 = new BankAccount(100, 200);
        System.out.println(BankAccount.accountCount());
        System.out.println(user1.getChecking());
    }
}
