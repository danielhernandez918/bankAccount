public class BankAccount {
    private double checkingBalance;
    private double savingsBalance;
    private static int numberOfAccounts =0;
    public BankAccount(){}
    
    public BankAccount(double checking, double savings) {
        checkingBalance  = checking;
        savingsBalance = savings;
        numberOfAccounts++;
    }

    public static int accountCount() {
        return numberOfAccounts;
    }

    public double getChecking() {
        return this.checkingBalance;
    }

    public double getSavings() {
        return this.savingsBalance;
    }
    public void depositChecking() {
        System.out.println("Please enter amount deposited:");
        String deposit = System.console().readLine();
        this.checkingBalance += double.parseInt(deposit);
    }
    public void depositSavings() {
        System.out.println("Please enter amount deposited:");
        String deposit = System.console().readLine();
        this.savingsBalance += double.parseInt(deposit);
    }
}